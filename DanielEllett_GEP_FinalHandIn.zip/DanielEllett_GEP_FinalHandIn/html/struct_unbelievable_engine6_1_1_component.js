var struct_unbelievable_engine6_1_1_component =
[
    [ "entity", "struct_unbelievable_engine6_1_1_component.html#acfff628ce8864e962e534889266c9f62", null ],
    [ "on_initialize", "struct_unbelievable_engine6_1_1_component.html#a6f09db0c0e4435e7bd257948ec29e009", null ],
    [ "on_render", "struct_unbelievable_engine6_1_1_component.html#af7ae6602c8081ae7126e764e9b9bb5df", null ],
    [ "on_tick", "struct_unbelievable_engine6_1_1_component.html#a3f8346732162c9254b4f7fc5a1410179", null ],
    [ "position", "struct_unbelievable_engine6_1_1_component.html#aeb779e2f639900a9440f89e408e92c9c", null ],
    [ "setPosition", "struct_unbelievable_engine6_1_1_component.html#a1ff3815fd2c7f7f9a33afe12e613b495", null ],
    [ "transform", "struct_unbelievable_engine6_1_1_component.html#a60e33efa1a5bfba47569eee8103a385e", null ]
];