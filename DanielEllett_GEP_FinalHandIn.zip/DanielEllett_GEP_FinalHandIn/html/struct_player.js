var struct_player =
[
    [ "on_initialize", "struct_player.html#ab24178844b96f9ec0c07c5c9a4c69b2c", null ],
    [ "on_tick", "struct_player.html#a19985b4ff32c47ee703466ce12a97158", null ]
];